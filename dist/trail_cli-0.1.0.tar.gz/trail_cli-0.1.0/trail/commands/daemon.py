from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import json
from time import monotonic, sleep
from typing import Annotated
from pathlib import Path
import os
import signal
import socket

import typer

from trail.commands.helpers import call_daemon
from trail.core.errors import TrailError
from trail.daemon.bootstrap import install_bootstrap, start_bootstrap, stop_bootstrap
from trail.daemon.client import daemon_transport_failure, format_exception_detail
from trail.daemon.manifest import load_manifest, manifest_path_for_user, save_manifest
from trail.daemon.paths import resolve_daemon_home
from trail.output.envelope import command_success
from trail.output.rendering import print_output


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def terminate_daemon_process(pid: int) -> None:
    os.kill(pid, signal.SIGTERM)


def runtime_endpoint_is_traild(
    *,
    endpoint: str,
    token: str,
    protocol_version: int,
    timeout_seconds: float = 0.2,
) -> bool:
    try:
        host, port_text = endpoint.split(":", 1)
        with socket.create_connection((host, int(port_text)), timeout=timeout_seconds) as sock:
            sock.settimeout(timeout_seconds)
            body = {
                "request_id": "daemon-control-ping",
                "protocol_version": protocol_version,
                "workspace_root": str(Path.cwd()),
                "session_id": None,
                "verbose": False,
                "method": "daemon.ping",
                "payload": {},
                "token": token,
            }
            sock.sendall(json.dumps(body, ensure_ascii=False).encode("utf-8") + b"\n")
            with sock.makefile("r", encoding="utf-8") as reader:
                response = json.loads(reader.readline())
    except (OSError, ValueError, json.JSONDecodeError):
        return False

    if not isinstance(response, dict):
        return False

    return response.get("ok") is True and response.get("data") == {"alive": True}


def runtime_manifest_is_live(manifest) -> bool:
    runtime = manifest.runtime
    if runtime.state not in {"ready", "degraded"} or not runtime.endpoint or not runtime.pid:
        return False

    try:
        token = Path(manifest.install.token_file).read_text(encoding="utf-8").strip()
    except OSError:
        return False
    if not token:
        return False

    return runtime_endpoint_is_traild(
        endpoint=runtime.endpoint,
        token=token,
        protocol_version=manifest.install.protocol_version,
    )


def clear_runtime_manifest_state(*, manifest_path: Path, manifest) -> None:
    manifest.runtime.state = "stopped"
    manifest.runtime.endpoint = None
    manifest.runtime.pid = None
    manifest.runtime.updated_at = _utc_now()
    manifest.runtime.last_transition_at = manifest.runtime.updated_at
    manifest.runtime.last_start_error = None
    token_path = Path(manifest.install.token_file)
    if token_path.exists():
        token_path.write_text("", encoding="utf-8")
    save_manifest(manifest_path, manifest)


def _load_manifest_for_command(*, daemon_home: Path, request_id: str):
    manifest_path = manifest_path_for_user(daemon_home)
    if not manifest_path.exists():
        return None, daemon_transport_failure(
            request_id=request_id,
            code="DAEMON_BOOTSTRAP_REQUIRED",
            message="daemon bootstrap not installed",
        )

    try:
        return load_manifest(manifest_path), None
    except Exception as error:
        return None, daemon_transport_failure(
            request_id=request_id,
            code="DAEMON_MANIFEST_INVALID",
            message="daemon manifest invalid",
            debug={"detail": format_exception_detail(error)},
        )


def ensure_bootstrap_installed(*, daemon_home: Path) -> Path:
    manifest_path = manifest_path_for_user(daemon_home)
    if manifest_path.exists():
        return manifest_path

    try:
        return install_bootstrap(daemon_home)
    except Exception as error:
        raise TrailError("DAEMON_INSTALL_FAILED", "daemon install failed") from error


def _poll_daemon_runtime_state(daemon_home: Path) -> str:
    try:
        manifest = load_manifest(manifest_path_for_user(daemon_home))
    except (OSError, ValueError, json.JSONDecodeError):
        return ""
    return str(manifest.runtime.state)


def ensure_runtime_ready(*, daemon_home: Path, timeout_seconds: float = 30.0, interval_seconds: float = 1.0) -> None:
    manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-start-run")
    if failure is not None:
        error = failure.get("error") or {}
        raise TrailError(str(error.get("code")), str(error.get("message")))

    if runtime_manifest_is_live(manifest) and _poll_daemon_runtime_state(daemon_home) == "ready":
        return

    if not runtime_manifest_is_live(manifest) and not start_bootstrap(daemon_home):
        raise TrailError("DAEMON_START_FAILED", "daemon start failed")

    deadline = monotonic() + timeout_seconds
    while monotonic() < deadline:
        manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-start-run")
        if failure is not None:
            sleep(interval_seconds)
            continue
        if runtime_manifest_is_live(manifest) and _poll_daemon_runtime_state(daemon_home) == "ready":
            return
        sleep(interval_seconds)

    raise TrailError("DAEMON_UNAVAILABLE", "daemon did not become ready in time")


daemon_app = typer.Typer(no_args_is_help=True)


@daemon_app.command("install")
def daemon_install() -> None:
    try:
        path = install_bootstrap(resolve_daemon_home())
    except Exception as error:
        print_output(
            "daemon.install",
            daemon_transport_failure(
                request_id="local-install",
                code="DAEMON_INSTALL_FAILED",
                message="daemon install failed",
                debug={"detail": format_exception_detail(error)},
            )
        )
        return

    print_output("daemon.install", command_success(data={"manifest_path": str(path)}, screenshot=None))


@daemon_app.command("start")
def daemon_start() -> None:
    daemon_home = resolve_daemon_home()
    manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-start")
    if failure is not None:
        print_output("daemon.start", failure)
        return

    if runtime_manifest_is_live(manifest):
        print_output("daemon.start", command_success(data={"started": False, "already_running": True}, screenshot=None))
        return

    if not start_bootstrap(daemon_home):
        print_output(
            "daemon.start",
            daemon_transport_failure(
                request_id="local-start",
                code="DAEMON_START_FAILED",
                message="daemon start failed",
            )
        )
        return

    print_output("daemon.start", command_success(data={"started": True}, screenshot=None))


@daemon_app.command("status")
def daemon_status() -> None:
    daemon_home = resolve_daemon_home()
    manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-status")
    if failure is not None:
        print_output("daemon.status", failure)
        return

    print_output(
        "daemon.status",
        command_success(
            data={
                "install": asdict(manifest.install),
                "runtime": asdict(manifest.runtime),
            },
            screenshot=None,
        )
    )


@daemon_app.command("stop")
def daemon_stop() -> None:
    daemon_home = resolve_daemon_home()
    manifest_path = manifest_path_for_user(daemon_home)
    manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-stop")
    if failure is not None:
        print_output("daemon.stop", failure)
        return

    runtime_is_live = runtime_manifest_is_live(manifest)
    if not runtime_is_live and (manifest.runtime.endpoint or manifest.runtime.pid):
        clear_runtime_manifest_state(manifest_path=manifest_path, manifest=manifest)
        print_output("daemon.stop", command_success(data={"stopped": True}, screenshot=None))
        return

    if manifest.runtime.pid is not None:
        try:
            stopped = stop_bootstrap(manifest.runtime.pid)
        except Exception as error:
            print_output(
                "daemon.stop",
                daemon_transport_failure(
                    request_id="local-stop",
                    code="DAEMON_STOP_FAILED",
                    message="daemon stop failed",
                    debug={
                        "detail": format_exception_detail(error),
                        "pid": manifest.runtime.pid,
                    },
                )
            )
            return

        if not stopped:
            print_output(
                "daemon.stop",
                daemon_transport_failure(
                    request_id="local-stop",
                    code="DAEMON_STOP_FAILED",
                    message="daemon stop failed",
                    debug={
                        "detail": "failed to launch elevated stop",
                        "pid": manifest.runtime.pid,
                    },
                )
            )
            return

    clear_runtime_manifest_state(manifest_path=manifest_path, manifest=manifest)
    print_output("daemon.stop", command_success(data={"stopped": True}, screenshot=None))


@daemon_app.command("restart")
def daemon_restart() -> None:
    daemon_home = resolve_daemon_home()
    manifest_path = manifest_path_for_user(daemon_home)
    manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-restart")
    if failure is not None:
        print_output("daemon.restart", failure)
        return

    stopped = False
    runtime_is_live = runtime_manifest_is_live(manifest)
    if not runtime_is_live and (manifest.runtime.endpoint or manifest.runtime.pid):
        clear_runtime_manifest_state(manifest_path=manifest_path, manifest=manifest)
        stopped = True
    elif manifest.runtime.pid is not None:
        try:
            stopped = stop_bootstrap(manifest.runtime.pid)
        except Exception as error:
            print_output(
                "daemon.restart",
                daemon_transport_failure(
                    request_id="local-restart",
                    code="DAEMON_STOP_FAILED",
                    message="daemon stop failed",
                    debug={
                        "detail": format_exception_detail(error),
                        "pid": manifest.runtime.pid,
                    },
                ),
            )
            return
        if not stopped:
            print_output(
                "daemon.restart",
                daemon_transport_failure(
                    request_id="local-restart",
                    code="DAEMON_STOP_FAILED",
                    message="daemon stop failed",
                    debug={
                        "detail": "failed to launch elevated stop",
                        "pid": manifest.runtime.pid,
                    },
                ),
            )
            return
        clear_runtime_manifest_state(manifest_path=manifest_path, manifest=manifest)

    if not start_bootstrap(daemon_home):
        print_output(
            "daemon.restart",
            daemon_transport_failure(
                request_id="local-restart",
                code="DAEMON_START_FAILED",
                message="daemon start failed",
            ),
        )
        return

    print_output(
        "daemon.restart",
        command_success(data={"stopped": stopped, "started": True, "already_running": False}, screenshot=None),
    )


@daemon_app.command("logs")
def daemon_logs() -> None:
    daemon_home = resolve_daemon_home()
    manifest, failure = _load_manifest_for_command(daemon_home=daemon_home, request_id="local-logs")
    if failure is not None:
        print_output("daemon.logs", failure)
        return

    print_output("daemon.logs", command_success(data={"log_dir": manifest.install.log_dir}, screenshot=None))


@daemon_app.command("request-status")
def daemon_request_status(request_id: Annotated[str, typer.Option("--request-id")]) -> None:
    print_output("daemon.request_status", call_daemon("daemon.request_status", {"request_id": request_id}))


@daemon_app.command("reconcile-session")
def daemon_reconcile_session(session: Annotated[str, typer.Option("--session")]) -> None:
    print_output("daemon.reconcile_session", call_daemon("daemon.reconcile_session", {"session_id": session}))
